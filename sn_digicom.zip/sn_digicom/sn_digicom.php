<?php
defined('_JEXEC') or die();

jimport('sncore.include');

class plgDigiCom_PaySn_digicom extends JPlugin
{
    protected $autoloadLanguage = true;

    function __construct(& $subject, $config)
    {
        parent::__construct($subject, $config);
        $this->responseStatus= array (
            'Completed' => 'A',
            'Pending' => 'P',
            'Failed' => 'P',
            'Denied' => 'P',
            'Refunded' => 'RF'
        );

        SNGlobal::loadLanguage('plg_digicom_pay_sn_digicom',JPATH_ADMINISTRATOR);
    }

    /* backend - plugin link */
    public function onDigicomSidebarMenuItem()
    {
        $extensionInfo = SNGlobal::selectByQuery("SELECT `extension_id` FROM `#__extensions` WHERE `element`='sn_digicom'",2);
        $extensionId = isset($extensionInfo['extension_id']) ? $extensionInfo['extension_id'] : 0;
        $link = JRoute::_("index.php?option=com_plugins&client_id=0&task=plugin.edit&extension_id=".$extensionId);
        $name = JText::_('SN_DIGICOM_MENU');
        return '<a target="_blank" href="'.$link.'" title="'.$name.'" id="plugin-'.$extensionId.'">' .$name. '</a>';
    }

    /* request */
    function onDigicom_PayGetHTML($vars,$pg_plugin)
    {
        if($pg_plugin != $this->_name)
        {
            return;
        }

        $app = JFactory::getApplication();

        $vars->custom_name= $this->params->get('plugin_name');
        $configs = JComponentHelper::getComponent('com_digicom')->params;
        $orderInfo = $this->_getOrderInfo($vars->order_id);

        $email = isset($vars->customer->email) ? $vars->customer->email : null;
        $phone = isset($vars->customer->phone) ? $vars->customer->phone : null;
        $amount = $orderInfo['amount'];
        $orderId = $vars->order_id;
        $backUrl = $vars->return;

        $pin = $this->params->get('sn_pin','');
        $currency = $this->params->get('sn_currency','');
        $sendPayerInfo = $this->params->get('sn_send_payer_info','');

        $amount = SNApi::modifyPrice($amount,$currency);

        $data = array(
            'pin'=> $pin,
            'price'=> $amount,
            'callback'=> $backUrl,
            'order_id'=> $orderId,
            'email'=> $email,
            'description'=> '',
            'mobile'=> $phone,
        );

        list($status,$msg,$resultData) = SNApi::request($data,$sendPayerInfo,'digicom');

        if($status == true)
        {
            $data['bank_callback_details'] = $resultData['bank_callback_details'];
            $data['au'] = $resultData['au'];

            SNApi::clearData();
            SNApi::setData($data);

            $vars->fields = $resultData['form_details']['fields'];
            $vars->urls = $resultData['form_details']['action'];
            $html = $this->_buildLayout($vars);

            return $html;
        }

        $errorMsg = '<h5>'.$msg.'</h5>';
        $app->enqueueMessage($errorMsg,'error');
        return false;
    }

    /* Verify */
    function onDigicom_PayProcesspayment($data)
    {
        $app = JFactory::getApplication();

        $orderId = SNGlobal::getVar('order_id','','none','request');
        $au = SNGlobal::getVar('au','','none','request');
        $processor = SNGlobal::getVar('processor','');

        if($processor != $this->_name || empty($orderId) || empty($au))
        {
            return false;
        }

        $sessionData = SNApi::getData();
        $orderInfo = $this->_getOrderInfo($orderId);
        if(empty($orderInfo) || $orderId != $sessionData['order_id'])
        {
            return false;
        }

        $bankData = array();
        foreach (!empty($sessionData['bank_callback_details']['params']) ? $sessionData['bank_callback_details']['params'] : array() as $bankParam)
        {
            $bankData[$bankParam] = !empty($_REQUEST[$bankParam]) ? $_REQUEST[$bankParam] : '';
        }

        $data = array (
            'pin' => $sessionData['pin'],
            'price' => $sessionData['price'],
            'order_id' => $sessionData['order_id'],
            'au' => $au,
            'bank_return' => $bankData,
        );

        list($status,$msg,$resultData) = SNApi::verify($data,'digicom');

        if($status == true)
        {
            $bankAu = !empty($resultData['bank_au']) ? $resultData['bank_au'] : $au;

            SNGlobal::update("UPDATE `#__digicom_orders` SET `amount_paid`='".SNGlobal::escape($orderInfo['amount'])."' WHERE `id`='".SNGlobal::escape($orderId)."'");
            $paymentStatus = $this->_translateResponse('Completed');
            $this->onDigicom_PayStorelog($this->_name,'Paid This Transaction : '.$orderId.'; Red Code : '.$bankAu);

            $successMsg = JText::_('SN_PAID_TRANSACTION');
            $successMsg = str_replace('{REF}',$bankAu,$successMsg);
            $app->enqueueMessage('<h5>'.$successMsg.'</h5>','message');
        }
        else
        {
            $paymentStatus = $this->_translateResponse('Failed');
            $this->onDigicom_PayStorelog($this->_name,'NOT Paid This Transaction : '.$orderId);

            $errorMsg = JText::_('SN_UNPAID_TRANSACTION');
            $app->enqueueMessage($errorMsg,'error');
        }

        $result = array(
            'transaction_id' =>	$this->_getUniqueTransactionId($orderId),
            'order_id' => $orderId,
            'status' =>	$paymentStatus,
            'raw_data' => json_encode($data),
            'processor' => $processor
        );

        if($status)
        {
            $result['tracking_code'] = " کد پیگیری ".$bankAu;
        }

        return $result;
    }

    function _buildLayout($vars)
    {
        $layout = JPATH_ROOT .DS. 'plugins'.DS.'digicom_pay'.DS.'sn_digicom'.DS.'sn_digicom'.DS.'tmpl'.DS.'default.php';

        ob_start();
        include($layout);
        $html = ob_get_contents();
        ob_end_clean();
        return $html;
    }

    function onDigicom_PayGetInfo($config)
    {
        if(!in_array($this->_name,$config))
        {
            return false;
        }

        $obj 		= new stdClass;
        $obj->name 	= $this->params->get( 'plugin_name' );
        $obj->id	= $this->_name;
        return $obj;
    }



    function _translateResponse($invoiceStatus)
    {
        return isset($this->responseStatus[$invoiceStatus]) ? $this->responseStatus[$invoiceStatus] : 'P';
    }

    function onDigicom_PayStorelog($name,$data)
    {
        if($name != $this->_name)
        {
            return;
        }

        $my = JFactory::getUser();

        jimport('joomla.error.log');
        JLog::addLogger(
            array(
                // Sets file name
                'text_file' => 'com_digicom.sn.errors.php'
            ),
            JLog::INFO,
            array('com_digicom.sn')
        );

        $message = 'Transaction added for ' . $my->name . '(' . $my->id . ')' . '. RawData: ' . json_encode($data['raw_data']);
        $logEntry = new JLogEntry($message , JLog::INFO, 'com_digicom.sn');

        JLog::add($logEntry);
    }

    function _getUniqueTransactionId($orderId)
    {
        $uniqueValue = $orderId.time();
        $long = md5(uniqid($uniqueValue,true));
        return substr($long,0,15);
    }

    function _getOrderInfo($orderId)
    {
        return SNGlobal::selectByQuery("SELECT `discount`,`tax`,`amount` FROM `#__digicom_orders` WHERE `id`='".SNGlobal::escape($orderId)."'",2);
    }
}