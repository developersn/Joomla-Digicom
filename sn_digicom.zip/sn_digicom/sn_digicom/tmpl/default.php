<?php
defined('_JEXEC') or die;
?>

<div class="sn-digicom-payment-form">
	<form action="<?php echo $vars->urls; ?>" name="adminForm" id="adminForm" class="form-validate form-horizontal"  method="post">
		<div>
			<div class="form-actions">
                <?php foreach (!empty($vars->fields) ? $vars->fields : array() as $key => $value): ?>
                    <input type="hidden" name="<?php echo $key ?>" value="<?php echo $value ?>" />
                <?php endforeach; ?>
			    <input type="submit" name="submit" class="btn btn-success btn-large btn-lg" value="<?php echo JText::_('SN_DIGICOM_PAID_BUTTON'); ?>" />
			</div>
		</div>
	</form>
</div>
